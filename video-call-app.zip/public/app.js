const localVideo=document.getElementById("localVideo");
const remoteVideo=document.getElementById("remoteVideo");

let localStream;
let peerConnection;

const protocol=location.protocol==="https:"?"wss":"ws";
const socket=new WebSocket(`${protocol}://${location.host}`);

const config={iceServers:[{urls:"stun:stun.l.google.com:19302"}]};

async function createPeer(){
peerConnection=new RTCPeerConnection(config);

localStream.getTracks().forEach(track=>{
peerConnection.addTrack(track,localStream);
});

peerConnection.ontrack=(event)=>{
remoteVideo.srcObject=event.streams[0];
};

peerConnection.onicecandidate=(event)=>{
if(event.candidate){
socket.send(JSON.stringify({
type:"candidate",
candidate:event.candidate
}));
}
};
}

document.getElementById("startBtn").onclick=async()=>{
localStream=await navigator.mediaDevices.getUserMedia({
video:true,
audio:true
});

localVideo.srcObject=localStream;
await createPeer();
};

document.getElementById("callBtn").onclick=async()=>{
const offer=await peerConnection.createOffer();
await peerConnection.setLocalDescription(offer);

socket.send(JSON.stringify({
type:"offer",
offer
}));
};

socket.onmessage=async(msg)=>{
const data=JSON.parse(msg.data);

switch(data.type){
case "offer":
if(!peerConnection){
await createPeer();
}

await peerConnection.setRemoteDescription(data.offer);

const answer=await peerConnection.createAnswer();
await peerConnection.setLocalDescription(answer);

socket.send(JSON.stringify({
type:"answer",
answer
}));
break;

case "answer":
await peerConnection.setRemoteDescription(data.answer);
break;

case "candidate":
try{
await peerConnection.addIceCandidate(data.candidate);
}catch(e){
console.error(e);
}
break;
}
};
