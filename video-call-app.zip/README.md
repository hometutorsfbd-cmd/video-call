# Simple Video Call

## Run locally

npm install
npm start

Open http://localhost:3000

## Deploy

Push to GitHub and deploy to a Node.js host such as Render, Railway, or a VPS.
